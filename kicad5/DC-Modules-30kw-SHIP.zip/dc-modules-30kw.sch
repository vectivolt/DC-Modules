EESchema Schematic File Version 4
EELAYER 30 0
EELAYER END
$Descr User 12000 8000
encoding utf-8
Sheet 1 1
Title "DC-Modules 30 kW module - schematic set"
Date "2026-09-06"
Rev "D.1"
Comp "DC-Modules"
Comment1 "AC-DC board (Vienna PFC) + DC-DC board (full-bridge LLC, E67)"
Comment2 "one Vienna PFC + one full-bridge LLC per module; one control card (E40)"
Comment3 ""
Comment4 ""
$EndDescr
$Sheet
S 1000 1000 4200 1400
U 5E000263
F0 "30 kW ACDC board 1of2 - Vienna PFC (1x cells)" 70
F1 "30kw-acdc.sch" 70
$EndSheet
$Sheet
S 6200 1000 4200 1400
U 5E000264
F0 "30 kW DCDC board 2of2 - full-bridge LLC (E67)" 70
F1 "30kw-dcdc.sch" 70
$EndSheet
$EndSCHEMATC
